import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


policy_name = 'TD3'
time_dir = '1561449674'
seed = 0
env_name = 'Hopper-v2'
file_name = "%s_%s_%s_%s" % (policy_name, env_name, str(seed),time_dir)
model_path = 'logs/%s/%s/%s.npy' % (policy_name, time_dir,file_name)
plot_path = 'logs/%s/%s/%s.jpg' % (policy_name, time_dir,file_name)


results = np.load(model_path)
results_tmp = results.tolist()
frame_id  = results_tmp.index(max(results_tmp))
print(results_tmp.index(max(results_tmp)))
max_rw = np.max(results)
plt.figure(figsize=(20, 5))
plt.subplot(131)
plt.title('frame id is %d, max reward: %s' % (frame_id, max_rw))
plt.plot(results)
# plt.show()
plt.savefig(plot_path)
plt.close('all')