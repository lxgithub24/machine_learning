import numpy as np
from collections import OrderedDict
import math
import random
import gym
import torch.nn as nn
import torch
import torch.nn.functional as F
from torch.distributions import Normal

# Code based on: 
# https://github.com/openai/baselines/blob/master/baselines/deepq/replay_buffer.py

# Expects tuples of (state, next_state, action, reward, done)
class ReplayBuffer(object):
	def __init__(self, max_size=1e6):
		self.storage = []
		self.max_size = max_size
		self.ptr = 0

	def add(self, data):
		if len(self.storage) == self.max_size:
			self.storage[int(self.ptr)] = data
			self.ptr = (self.ptr + 1) % self.max_size
		else:
			self.storage.append(data)

	def sample(self, batch_size):
		ind = np.random.randint(0, len(self.storage), size=batch_size)
		x, y, u, r, d = [], [], [], [], []

		for i in ind: 
			X, Y, U, R, D = self.storage[i]
			x.append(np.array(X, copy=False))
			y.append(np.array(Y, copy=False))
			u.append(np.array(U, copy=False))
			r.append(np.array(R, copy=False))
			d.append(np.array(D, copy=False))

		return np.array(x), np.array(y), np.array(u), np.array(r).reshape(-1, 1), np.array(d).reshape(-1, 1)


class Memory(nn.Module):
    """Linear memory, allows storing information in its weights.
    """

    def __init__(self, size_in=None, size_out=None):
        super(Memory, self).__init__()
        assert size_in is not None
        assert size_out is not None
        def init_weights(m):
            if type(m) == nn.Linear:
                torch.nn.init.xavier_uniform(m.weight)
                m.bias.data.fill_(0.0)

        shp = size_out, size_in
        # Correctly init weights.
        '''
        self._b = torch.zeros(shp[0], requires_grad=True).cuda()
        self._w = torch.randn(*shp, requires_grad=True).cuda()
        std = 0.01
        stdv = std / math.sqrt(self._w.size(1))
        self._w.data.uniform_(-stdv, stdv)

        self.train_vars = [self._w, self._b]
        '''
        self.mem_d0 = nn.Sequential(
            nn.Linear(in_features=shp[1], out_features=shp[0]),
            nn.Tanh()).cuda()
        self.mem_d0.apply(init_weights)

    def f(self):
        x = torch.ones(self._w.shape[1], requires_grad=False).cuda()
        # Needs nonlinearity after memory
        return self.mem_d0(x)


class NormalizedActions(gym.ActionWrapper):

    def _action(self, action):
        low_bound = self.action_space.low
        upper_bound = self.action_space.high

        action = low_bound + (action + 1.0) * 0.5 * (upper_bound - low_bound)
        action = np.clip(action, low_bound, upper_bound)

        return action

    def _reverse_action(self, action):
        low_bound = self.action_space.low
        upper_bound = self.action_space.high

        action = 2 * (action - low_bound) / (upper_bound - low_bound) - 1
        action = np.clip(action, low_bound, upper_bound)

        return action

class OUNoise(object):
    def __init__(self, action_space, mu=0.0, theta=0.15, max_sigma=0.3, min_sigma=0.1, decay_period=100000):
        self.mu = mu
        self.theta = theta
        self.sigma = max_sigma
        self.max_sigma = max_sigma
        self.min_sigma = min_sigma
        self.decay_period = decay_period
        self.action_dim = action_space.shape[0]
        self.low = action_space.low
        self.high = action_space.high
        self.reset()

    def reset(self):
        self.state = np.ones(self.action_dim) * self.mu

    def evolve_state(self):
        x = self.state
        dx = self.theta * (self.mu - x) + self.sigma * np.random.randn(self.action_dim)
        self.state = x + dx
        return self.state

    def get_action(self, action, t=0):
        ou_state = self.evolve_state()
        self.sigma = self.max_sigma - (self.max_sigma - self.min_sigma) * min(1.0, t / self.decay_period)
        return np.clip(action + ou_state, self.low, self.high)


class ValueNetwork(nn.Module):
    def __init__(self, num_inputs, num_actions, hidden_size, init_w=3e-3):
        super(ValueNetwork, self).__init__()

        self.linear1 = nn.Linear(num_inputs + num_actions, hidden_size)
        self.linear2 = nn.Linear(hidden_size, hidden_size)
        self.linear3 = nn.Linear(hidden_size, 1)

        self.linear3.weight.data.uniform_(-init_w, init_w)
        self.linear3.bias.data.uniform_(-init_w, init_w)

    def forward(self, state, action):
        x = torch.cat([state, action], 1)
        x = F.relu(self.linear1(x))
        x = F.relu(self.linear2(x))
        x = self.linear3(x)
        return x


class PolicyFeature(nn.Module):
    def __init__(self, num_inputs, hidden_size):
        super(PolicyFeature, self).__init__()

        self.linear1 = nn.Linear(num_inputs, hidden_size)
        self.linear2 = nn.Linear(hidden_size, hidden_size)

    def forward(self, state):
        x = F.relu(self.linear1(state))
        x = F.relu(self.linear2(x))

        return x


class PolicyNetwork_D(nn.Module):
    def __init__(self, num_actions, hidden_size, init_w=3e-3):
        super(PolicyNetwork_D, self).__init__()
        self.linear3 = nn.Linear(hidden_size, num_actions)

        self.linear3.weight.data.uniform_(-init_w, init_w)
        self.linear3.bias.data.uniform_(-init_w, init_w)

    def forward(self, state):
        x = F.tanh(self.linear3(state))
        return x

    def get_action(self, state):
        action = self.forward(state)
        return action.detach().cpu().numpy()[0]



class PolicyNetwork(nn.Module):
    def __init__(self, num_inputs, num_actions, hidden_size,device, init_w=3e-3):
        super(PolicyNetwork, self).__init__()

        self.linear1 = nn.Linear(num_inputs, hidden_size)
        self.linear2 = nn.Linear(hidden_size, hidden_size)
        self.linear3 = nn.Linear(hidden_size, num_actions)

        self.linear3.weight.data.uniform_(-init_w, init_w)
        self.linear3.bias.data.uniform_(-init_w, init_w)
        self.device = device

    def forward(self, state):
        x = F.relu(self.linear1(state))
        x = F.relu(self.linear2(x))
        x = F.tanh(self.linear3(x))
        return x

    def get_action(self, state):
        state = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        action = self.forward(state)
        return action.detach().cpu().numpy()[0]



class SharedAdam(torch.optim.Adam):
    def __init__(self, params, lr=1e-3, betas=(0.9, 0.9), eps=1e-8,
                 weight_decay=0):
        super(SharedAdam, self).__init__(params, lr=lr, betas=betas, eps=eps, weight_decay=weight_decay)
        # State initialization
        for group in self.param_groups:
            for p in group['params']:
                state = self.state[p]
                state['step'] = 0
                state['exp_avg'] = torch.zeros_like(p.data)
                state['exp_avg_sq'] = torch.zeros_like(p.data)

                # share in memory
                state['exp_avg'].share_memory_()
                state['exp_avg_sq'].share_memory_()


def record(global_ep, global_ep_r, ep_r, res_queue, name):
    with global_ep.get_lock():
        global_ep.value += 1
    with global_ep_r.get_lock():
        if global_ep_r.value == 0.:
            global_ep_r.value = ep_r
        else:
            #global_ep_r.value = global_ep_r.value * 0.99 + ep_r * 0.01
            global_ep_r.value = ep_r
    res_queue.put(global_ep_r.value)
    print(
        name,
        "Ep:", global_ep.value,
        "| Ep_r: %.2f" % global_ep_r.value,
    )

class Normalizer(object):
    def __init__(self, shape, epsilon=1e-2):
        self.shape = shape
        self.sum = np.zeros(shape, dtype=np.float32)
        self.sum2 = np.full(shape, epsilon, dtype=np.float32)
        self.count = epsilon

    def _get_mean_and_std(self):
        mean = self.sum / self.count
        std = np.sqrt(np.maximum(self.sum2 / self.count - np.square(mean), 0.01))
        return mean, std

    def update(self, x):
        self.sum += np.sum(x, axis=0)
        self.sum2 += np.sum(np.square(x), axis=0)
        self.count += x.shape[0]

    def norm(self, x):
        mean, std = self._get_mean_and_std()
        return (x - mean) / std

    def unnorm(self, x):
        mean, std = self._get_mean_and_std()
        return mean + x * std


def write_log(log, log_path):
    f = open(log_path, mode='a')
    f.write(str(log))
    f.write('\n')
    f.close()

class Hot_Plug(object):
    def __init__(self, model):
        self.model = model
        self.params = OrderedDict(self.model.named_parameters())
    def update(self, lr=0.1):
        for param_name in self.params.keys():
            path = param_name.split('.')
            cursor = self.model
            for module_name in path[:-1]:
                cursor = cursor._modules[module_name]
            if lr > 0:
                cursor._parameters[path[-1]] = self.params[param_name] - lr*self.params[param_name].grad
            else:
                cursor._parameters[path[-1]] = self.params[param_name]
    def restore(self):
        self.update(lr=0)

class Critic_Network(nn.Module):
    def __init__(self, hidden_dim):
        super(Critic_Network, self).__init__()
        self.fc1 = nn.Linear(hidden_dim,100)
        self.fc2 = nn.Linear(100,100)
        self.fc3 = nn.Linear(100,1)
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = nn.functional.softplus(self.fc3(x))
        return torch.mean(x)
'''

class Critic_Network(nn.Module):
    def __init__(self, hidden_dim):
        super(Critic_Network, self).__init__()
        self.fc1 = nn.Linear(hidden_dim,64)
        self.fc2 = nn.Linear(64,64)
        self.fc3 = nn.Linear(64,1)
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = nn.functional.softplus(self.fc3(x))
        return torch.mean(x)


class Critic_Network(nn.Module):
    def __init__(self, hidden_dim):
        super(Critic_Network, self).__init__()
        self.fc1 = nn.Linear(hidden_dim,100)
        self.fc2 = nn.Linear(100,1)
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = nn.functional.softplus(self.fc2(x))
        return torch.mean(x)
'''
def linear_interpolation(l, r, alpha):
    return l + alpha * (r - l)


class PiecewiseSchedule(object):
    def __init__(self, endpoints, interpolation=linear_interpolation, outside_value=None):
        idxes = [e[0] for e in endpoints]
        assert idxes == sorted(idxes)
        self._interpolation = interpolation
        self._outside_value = outside_value
        self._endpoints = endpoints

    def value(self, t):
        for (l_t, l), (r_t, r) in zip(self._endpoints[:-1], self._endpoints[1:]):
            if l_t <= t < r_t:
                alpha = float(t - l_t) / (r_t - l_t)
                return self._interpolation(l, r, alpha)

        assert self._outside_value is not None
        return self._outside_value

def gamma_expand(x, a):
    x, a = np.asarray(x), np.asarray(a)
    y = np.zeros_like(x)
    for t in reversed(range(len(x))):
        y[t] = x[t] + a[t] * (0 if t == len(x) - 1 else y[t + 1])
    return y


import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
def plot_results(model_path, plot_path):
    results = np.load(model_path)
    results_tmp = results.tolist()
    frame_id = results_tmp.index(max(results_tmp))
    print(results_tmp.index(max(results_tmp)))
    max_rw = np.max(results)
    plt.figure(figsize=(20, 5))
    plt.subplot(131)
    plt.title('frame id is %d, max reward: %s' % (frame_id, max_rw))
    plt.plot(results)
    # plt.show()
    plt.savefig(plot_path)
    plt.close('all')