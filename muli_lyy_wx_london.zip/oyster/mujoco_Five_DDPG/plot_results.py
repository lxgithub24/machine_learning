import numpy as np
import matplotlib.pyplot as plt

env_name = 'inverted_pendulum'
time_dir = '1558784380'

method = 'ddpg_aux'
model_path = 'logs/%s/%s/%s/%s.npy'%(env_name, method, time_dir, method)
plot_path = 'logs/%s/%s/%s/%s_max.jpg'%(env_name, method, time_dir, method)


results = np.load(model_path)
results_tmp = results.tolist()
frame_id = results_tmp.index(max(results_tmp))
max_rw = np.max(results)
plt.figure(figsize = (20,5))
plt.subplot(131)
plt.title('frame is is %d, max reward: %s'%(frame_id, max_rw))
plt.plot(results)
plt.savefig(plot_path)
plt.close('all')