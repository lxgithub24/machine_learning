class HyperParams:
    critic_lr = 1e-3
    actor_lr = 1e-4
    actor_feature_lr = 1e-4
    aux_lr = 1e-3
    weight_decay = 1e-4
    mem_lr = 1e-4
    beta = 1
    batch_size = 128
