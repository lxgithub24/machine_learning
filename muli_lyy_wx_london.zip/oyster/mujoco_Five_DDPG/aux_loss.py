import torch
import torch.nn as nn
import torch.nn.functional as F

class Conv1DLoss(nn.Module):
    """Convolutional 1D loss: temporal conv, features are channels.
    """
    def __init__(self, traj_dim_in, traj_dim_out):
        super(Conv1DLoss, self).__init__()
        chan_traj_c0_c1 = 16
        chan_traj_c1_d0 = 32
        units_traj_d0_d1 = 32
        units_traj_d1_d2 = 16
        def init_weights(m):
            if type(m) == nn.Linear:
                torch.nn.init.xavier_uniform(m.weight)
                m.bias.data.fill_(0.0)

        # This means, 1 input dimension (so we convolve along the temporal axis) and treat
        # each feature dimension as a channel. The temporal axis is always the same length
        # since this is fixed with a buffer that keeps track of the latest data.

        self.traj_c =nn.Sequential(
                     nn.Conv1d(in_channels=traj_dim_in, out_channels=chan_traj_c0_c1, kernel_size=6, stride=5),
                     nn.ReLU(),
                     nn.Conv1d(in_channels=chan_traj_c0_c1, out_channels=chan_traj_c1_d0, kernel_size=4, stride=2),
                     nn.ReLU()
                     ).cuda()

        self.traj_d0 = nn.Linear(in_features=chan_traj_c1_d0, out_features=units_traj_d0_d1).cuda()

        self.loss_d = nn.Sequential(
                      nn.Linear(in_features=traj_dim_in + units_traj_d0_d1, out_features=units_traj_d1_d2),
                      nn.ReLU(),
                      nn.Linear(in_features=units_traj_d1_d2, out_features=1),
                      nn.Softplus()
                     ).cuda()

        self.traj_c.apply(init_weights)
        self.traj_d0.apply(init_weights)
        self.loss_d.apply(init_weights)
        '''
        self.omega_traj_c = [torch.randn(16, 272, 6, requires_grad=True).cuda(),
                      torch.randn(16, requires_grad=True).cuda(),
                      torch.randn(32, 16,4, requires_grad=True).cuda(),
                      torch.randn(32, requires_grad=True).cuda()]

        self.omega_traj_d = [torch.randn(32, 32, requires_grad=True).cuda(),
                             torch.randn(32, requires_grad=True).cuda()]

        self.omega_loss_c = [torch.randn(64, 304, requires_grad=True).cuda(),
                             torch.randn(64, requires_grad=True).cuda(),
                             torch.randn(traj_dim_out, 64, requires_grad=True).cuda(),
                             torch.randn(traj_dim_out, requires_grad=True).cuda()]

        self.omega = self.omega_traj_c + self.omega_traj_d + self.omega_loss_c

        for v in self.omega:
            if len(v.shape) > 1:
                torch.nn.init.xavier_normal_(v)
            else:
                torch.nn.init.constant(v, 0)
                
        '''

    def process_trajectory(self, l):
        """This is the time-dependent convolution operation, applied to a trajectory (in order).
        """
        shp = l.shape[0]
        shx = l.shape[1]
        # First dim is batchsize=1, then either 1 channel for 2d conv or n_feat channels
        # for 1d conv.
        l = l.view(1, shp, shx)
        l = l.transpose(1,2)
        #l = F.leaky_relu(F.conv1d(F.leaky_relu(F.conv1d(l,self.omega_traj_c[0],self.omega_traj_c[1])),self.omega_traj_c[2],self.omega_traj_c[3]))
        l = self.traj_c(l)
        l = torch.sum(l, dim=(0, 2)) / l.shape[0] / l.shape[2]
        l = l.view(1, l.shape[0])
        #l = F.linear(l,self.omega_traj_d[0],self.omega_traj_d[1])
        l = self.traj_d0(l)
        l = l.repeat(shp, 1)
        return l

    def loss(self, l):
        """Loss function, can be calculated over a minibatch of data (out of order).
        """

        #return torch.mean(F.linear(F.leaky_relu(F.linear(l, self.omega_loss_c[0], self.omega_loss_c[1])),
        #          self.omega_loss_c[2], self.omega_loss_c[3])).cuda()
        #return torch.mean(F.softplus(F.linear(F.leaky_relu(F.linear(l, self.omega_loss_c[0], self.omega_loss_c[1])),
        # self.omega_loss_c[2], self.omega_loss_c[3]))).cuda()
        #l = F.linear(F.leaky_relu(F.linear(l, self.omega_loss_c[0], self.omega_loss_c[1])), self.omega_loss_c[2], self.omega_loss_c[3]).cuda()
        #return torch.mean(F.linear(F.leaky_relu(F.linear(l, self.omega_loss_c[0], self.omega_loss_c[1])), self.omega_loss_c[2],
        #                           self.omega_loss_c[3])).cuda()
        # # Explicit addition of policy output.
        l = self.loss_d(l)
        l = torch.mean(l)
        # Average accross minibatch

        return l
