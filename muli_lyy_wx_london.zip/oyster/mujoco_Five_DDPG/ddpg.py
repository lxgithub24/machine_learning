
import numpy as np

import torch
import torch.nn as nn
import torch.optim as optim

from hparams import HyperParams as hp
from utils import write_log, ReplayBuffer, NormalizedActions,OUNoise, ValueNetwork,PolicyNetwork, plot
import time
import os

use_cuda = torch.cuda.is_available()
device   = torch.device("cuda" if use_cuda else "cpu")


def ddpg_update(batch_size,
                gamma=0.99,
                min_value=-np.inf,
                max_value=np.inf,
                soft_tau=1e-2):
    state, action, reward, next_state, done = replay_buffer.sample(batch_size)

    state = torch.FloatTensor(state).to(device)
    next_state = torch.FloatTensor(next_state).to(device)
    action = torch.FloatTensor(action).to(device)
    reward = torch.FloatTensor(reward).unsqueeze(1).to(device)
    done = torch.FloatTensor(np.float32(done)).unsqueeze(1).to(device)

    policy_loss = value_net(state, policy_net(state))
    policy_loss = -policy_loss.mean()

    next_action = target_policy_net(next_state)
    target_value = target_value_net(next_state, next_action.detach())
    expected_value = reward + (1.0 - done) * gamma * target_value
    expected_value = torch.clamp(expected_value, min_value, max_value)

    value = value_net(state, action)
    value_loss = value_criterion(value, expected_value.detach())

    policy_optimizer.zero_grad()
    policy_loss.backward()
    policy_optimizer.step()

    value_optimizer.zero_grad()
    value_loss.backward()
    value_optimizer.step()

    for target_param, param in zip(target_value_net.parameters(), value_net.parameters()):
        target_param.data.copy_(
            target_param.data * (1.0 - soft_tau) + param.data * soft_tau
        )

    for target_param, param in zip(target_policy_net.parameters(), policy_net.parameters()):
        target_param.data.copy_(
            target_param.data * (1.0 - soft_tau) + param.data * soft_tau
        )


from mujoco_envs.half_cheetah import HalfCheetahEnv
from mujoco_envs.hopper import HopperEnv
from mujoco_envs.inverted_pendulum import InvertedPendulumEnv
from mujoco_envs.inverted_double_pendulum import InvertedDoublePendulumEnv
from mujoco_envs.walker2d import Walker2dEnv

env_name = "inverted_double_pendulum"

if env_name == "half_cheetah":
    env = NormalizedActions(HalfCheetahEnv())
elif env_name == "hopper":
    env = NormalizedActions(HopperEnv())
elif env_name == "inverted_pendulum":
    env = NormalizedActions(InvertedPendulumEnv())
elif env_name == "inverted_double_pendulum":
    env = NormalizedActions(InvertedDoublePendulumEnv())
elif env_name == "walker2d":
    env = NormalizedActions(Walker2dEnv())

time_dir = str(int(time.time()))
if not os.path.exists('logs/%s/ddpg/%s/'%(env_name,time_dir)):
    os.makedirs('logs/%s/ddpg/%s/'%(env_name,time_dir))
if not os.path.exists('model_output/%s/ddpg/%s/'%(env_name,time_dir)):
    os.makedirs('model_output/%s/ddpg/%s/'%(env_name,time_dir))

flags_log = os.path.join('logs/%s/ddpg/%s/'%(env_name,time_dir), 'ddpg_training_log.txt')
model_path = 'model_output/%s/ddpg/%s/'%(env_name,time_dir)
plot_path = 'logs/%s/ddpg/%s/ddpg.jpg' % (env_name,time_dir)

hp_log = {}

hp_log['critic_lr'] = hp.critic_lr
hp_log['actor_lr'] = hp.actor_lr
hp_log['batch_size'] = hp.batch_size
hp_log['env_name'] = env_name
hp_log['time_dir'] = time_dir
hp_log['method'] = "ddpg"

write_log(hp_log, flags_log)
print(hp_log)

#env = NormalizedActions(gym.make("Pendulum-v0"))
#env = NormalizedActions(gym.make("Hopper-v2"))
ou_noise = OUNoise(env.action_space)

state_dim = env.observation_space.shape[0]
action_dim = env.action_space.shape[0]
hidden_dim = 256

value_net = ValueNetwork(state_dim, action_dim, hidden_dim).to(device)
policy_net = PolicyNetwork(state_dim, action_dim, hidden_dim, device).to(device)

target_value_net = ValueNetwork(state_dim, action_dim, hidden_dim).to(device)
target_policy_net = PolicyNetwork(state_dim, action_dim, hidden_dim, device).to(device)

for target_param, param in zip(target_value_net.parameters(), value_net.parameters()):
    target_param.data.copy_(param.data)

for target_param, param in zip(target_policy_net.parameters(), policy_net.parameters()):
    target_param.data.copy_(param.data)

value_lr = hp.critic_lr
policy_lr = hp.actor_lr

value_optimizer = optim.Adam(value_net.parameters(), lr=value_lr)
policy_optimizer = optim.Adam(policy_net.parameters(), lr=policy_lr)

value_criterion = nn.MSELoss()

replay_buffer_size = 1000000
replay_buffer = ReplayBuffer(replay_buffer_size)

max_frames  = 10000
max_steps   = 500
frame_idx   = 0
rewards     = []
batch_size  = hp.batch_size

max_reward = 0.0
TEST = 10
state = env.reset()
while frame_idx < max_frames:
    state = env.reset()
    ou_noise.reset()
    episode_reward = 0
    for step in range(1000):
        action = policy_net.get_action(state)
        action = ou_noise.get_action(action, step)
        next_state, reward, done, _ = env.step(action)

        replay_buffer.push(state, action, reward, next_state, done)
        if len(replay_buffer) > batch_size:
            ddpg_update(batch_size)

        state = next_state
        episode_reward += reward
        if done:
            break

    if frame_idx > 100:
        episode_reward = 0
        for i in range(TEST):
            state_test = env.reset()
            for step in range(2000):
                action = policy_net.get_action(state_test)
                next_state, reward, done, _ = env.step(action)
                state_test = next_state
                episode_reward += reward
                if done:
                    break
        episode_reward = episode_reward / TEST
        if episode_reward > max_reward:
            print('greedy reward')
            max_reward = episode_reward
            outfile = os.path.join(model_path, 'best_model.tar')
            torch.save((policy_net.state_dict(),value_net.state_dict()), outfile)
        print('frame_idx is %d, step is %d, reward is %f.' % (frame_idx, step, episode_reward))

        rewards.append(episode_reward)
        plot(frame_idx, rewards, plot_path)

    frame_idx += 1

np.save('logs/%s/ddpg/%s/ddpg'%(env_name,time_dir), rewards)
