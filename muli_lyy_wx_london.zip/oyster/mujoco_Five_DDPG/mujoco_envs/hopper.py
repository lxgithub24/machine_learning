import numpy as np
from gym import utils
from gym.envs.mujoco import mujoco_env

class HopperEnv(mujoco_env.MujocoEnv, utils.EzPickle):
    def __init__(self):
        # self.default_env: 
        #    0: mass of body
        #    1: horizontal wind condition
        #    2: vertical gravity condition
        #    3: overall friction co_eff

        self.noise_type = None
        self.noise_scale = 0.
        mujoco_env.MujocoEnv.__init__(self, 'hopper.xml', 4)
        self.default_env = [self.model.body_mass, self.model.opt.gravity[0], self.model.opt.gravity[2], self.model.geom_friction[:,0]]
        utils.EzPickle.__init__(self)

    def step(self, a):
        if self.noise_type is 'env':
            noise = np.random.normal(loc = 0., scale=self.noise_scale,size=4)
            self.change_env(noise = noise)
        posbefore = self.sim.data.qpos[0]
        if self.noise_type is 'act':
            noise = np.random.normal(loc=0.,scale=self.noise_scale,size=np.shape(a))
            self.do_simulation(a+noise, self.frame_skip)
        else:
            self.do_simulation(a, self.frame_skip)
        #self.do_simulation(a, self.frame_skip)
        posafter, height, ang = self.sim.data.qpos[0:3]
        alive_bonus = 1.0
        reward = (posafter - posbefore) / self.dt
        reward += alive_bonus
        reward -= 1e-3 * np.square(a).sum()
        s = self.state_vector()
        done = not (np.isfinite(s).all() and (np.abs(s[2:]) < 100).all() and
                    (height > .7) and (abs(ang) < .2))
        ob = self._get_obs()
        return ob, reward, done, {}

    def _get_obs(self):
        obs = np.concatenate([self.sim.data.qpos.flat[1:], np.clip(self.sim.data.qvel.flat, -10,10)])
        if self.noise_type is 'obs':
            noise = np.random.normal(loc = 0., scale = self.noise_scale, size = obs.shape)
            return obs + noise
        else:
            return obs

    def reset_model(self):
        if self.noise_type is 'dom':
            noise = np.random.normal(loc = 0., scale = self.noise_scale, size = 4)
            self.change_env(noise = noise)
        else:
            self.reset_env()
        qpos = self.init_qpos + self.np_random.uniform(low=-.005, high=.005, size=self.model.nq)
        qvel = self.init_qvel + self.np_random.uniform(low=-.005, high=.005, size=self.model.nv)
        self.set_state(qpos, qvel)
        return self._get_obs()

    def viewer_setup(self):
        self.viewer.cam.trackbodyid = 2
        self.viewer.cam.distance = self.model.stat.extent * 0.75
        self.viewer.cam.lookat[2] = 1.15
        self.viewer.cam.elevation = -20

    def modify_env(self, noise_type = 'obs', noise_scale = 0.):
        self.noise_type = noise_type
        self.noise_scale = noise_scale

    def reset_env(self):
        for gf,dv in zip(self.model.body_mass, self.default_env[0]):
            gf = dv
        self.model.opt.gravity[0] = self.default_env[1]
        self.model.opt.gravity[2] = self.default_env[2]
        for gf,dv in zip(self.model.geom_friction[:,0], self.default_env[3]):
            gf = dv

    def change_env(self, noise = 0.0):
        noise0 = np.clip(noise[0] * .5, -.5, .5)
        for gf, dv in zip(self.model.body_mass, self.default_env[0]):
            gf = dv * (1. + noise0)
        self.model.opt.gravity[0] = self.default_env[1] + np.clip(noise[1] * 2.5, -5., 5.)
        self.model.opt.gravity[2] = self.default_env[2] + np.clip(noise[2] * 2.5, -5., 5.)
        noise1 = np.clip(noise[3] * .5, -.5, .5)
        for gf, dv in zip(self.model.geom_friction[:,0], self.default_env[3]):
            gf = dv * (1. + noise1)
