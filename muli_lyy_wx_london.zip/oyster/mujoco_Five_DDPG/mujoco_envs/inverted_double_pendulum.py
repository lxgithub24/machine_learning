import numpy as np
from gym import utils
from gym.envs.mujoco import mujoco_env

class InvertedDoublePendulumEnv(mujoco_env.MujocoEnv, utils.EzPickle):

    def __init__(self):
        # self.default_env: 
        #    0: mass of cart
        #    1: mass of pole 1
        #    2: mass of pole 2
        #    3: vertical gravity condition
        #    4: overall friction co_eff

        self.noise_type = None
        self.noise_scale = 0.
        mujoco_env.MujocoEnv.__init__(self, 'inverted_double_pendulum.xml', 5)
        self.default_env = [self.model.body_mass[1], self.model.body_mass[2], self.model.body_mass[3], self.model.opt.gravity[2], self.model.geom_friction[:,0]]

        utils.EzPickle.__init__(self)

    def step(self, a):
        if self.noise_type is 'env':
            noise = np.random.normal(loc = 0., scale=self.noise_scale,size=5)
            self.change_env(noise = noise)
        posbefore = self.sim.data.qpos[0]
        if self.noise_type is 'act':
            noise = np.random.normal(loc=0.,scale=self.noise_scale,size=np.shape(a))
            self.do_simulation(a+noise, self.frame_skip)
        else:
            self.do_simulation(a, self.frame_skip)
        ob = self._get_obs()
        x, _, y = self.sim.data.site_xpos[0]
        dist_penalty = 0.01 * x ** 2 + (y - 2) ** 2
        v1, v2 = self.sim.data.qvel[1:3]
        vel_penalty = 1e-3 * v1**2 + 5e-3 * v2**2
        alive_bonus = 10
        r = alive_bonus - dist_penalty - vel_penalty
        done = bool(y <= 1)
        return ob, r, done, {}

    def _get_obs(self):
        obs = np.concatenate([
            self.sim.data.qpos[:1],  # cart x pos
            np.sin(self.sim.data.qpos[1:]),  # link angles
            np.cos(self.sim.data.qpos[1:]),
            np.clip(self.sim.data.qvel, -10, 10),
            np.clip(self.sim.data.qfrc_constraint, -10, 10)
        ]).ravel()

        if self.noise_type is 'obs':
            noise = np.random.normal(loc = 0., scale = self.noise_scale, size = obs.shape)
            return obs + noise 
        else:
            return obs

    def reset_model(self):
        if self.noise_type is 'dom':
            noise = np.random.normal(loc = 0., scale = self.noise_scale, size = 5)
            self.change_env(noise = noise)
        else:
            self.reset_env()
        self.set_state(
            self.init_qpos + self.np_random.uniform(low=-.1, high=.1, size=self.model.nq),
            self.init_qvel + self.np_random.randn(self.model.nv) * .1
        )
        return self._get_obs()

    def viewer_setup(self):
        v = self.viewer
        v.cam.trackbodyid = 0
        v.cam.distance = self.model.stat.extent * 0.5
        v.cam.lookat[2] = 0.12250000000000005  # v.model.stat.center[2]

    def modify_env(self, noise_type = 'obs', noise_scale = 0.):
        self.noise_type = noise_type
        self.noise_scale = noise_scale
        
    def reset_env(self):
        self.model.body_mass[1] = self.default_env[0]
        self.model.body_mass[2] = self.default_env[1]
        self.model.body_mass[3] = self.default_env[2]
        self.model.opt.gravity[2] = self.default_env[3]
        for gf,dv in zip(self.model.geom_friction[:,0], self.default_env[4]):
            gf = dv

    def change_env(self, noise = 0.0):
        noise0 = np.clip(noise[0] * .5, -.5, .5)
        self.model.body_mass[1] = self.default_env[0] * (1 + noise0)
        noise1 = np.clip(noise[1] * .5, -.5, .5)
        self.model.body_mass[2] = self.default_env[1] * (1 + noise1)
        noise2 = np.clip(noise[2] * .5, -.5, .5)
        self.model.body_mass[3] = self.default_env[2] * (1 + noise2)
        self.model.opt.gravity[2] = self.default_env[3] + np.clip(noise[3] * 2.5, -5., 5.)
        noise4 = np.clip(noise[4] * .5, -.5, .5)
        for gf, dv in zip(self.model.geom_friction[:,0], self.default_env[4]):
            gf = dv * (1. + noise4)
