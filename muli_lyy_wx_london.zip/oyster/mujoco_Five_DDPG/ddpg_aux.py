import math
import random

import gym
import numpy as np

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.distributions import Normal
from hparams import HyperParams as hp
from collections import OrderedDict
from utils import write_log, ReplayBuffer, NormalizedActions,OUNoise, ValueNetwork,PolicyNetwork, plot, Hot_Plug, Critic_Network, PolicyFeature, PolicyNetwork_D
import os
import time

use_cuda = torch.cuda.is_available()
device   = torch.device("cuda" if use_cuda else "cpu")

def ddpg_update(batch_size,
                gamma=0.99,
                min_value=-np.inf,
                max_value=np.inf,
                soft_tau=1e-2):
    state, action, reward, next_state, done = replay_buffer.sample(batch_size)
    state_val, action_val, reward_val, next_state_val, done_val = replay_buffer.sample(batch_size)

    state = torch.FloatTensor(state).to(device)
    next_state = torch.FloatTensor(next_state).to(device)
    action = torch.FloatTensor(action).to(device)
    reward = torch.FloatTensor(reward).unsqueeze(1).to(device)
    done = torch.FloatTensor(np.float32(done)).unsqueeze(1).to(device)

    state_feature = policy_feature_net(state)
    loss_auxiliary = hp.beta * critic(state_feature)

    policy_loss = value_net(state, policy_net(state_feature))
    policy_loss = -policy_loss.mean()

    next_state_feature = target_policy_feature_net(next_state)
    next_action = target_policy_net(next_state_feature)
    target_value = target_value_net(next_state, next_action.detach())
    expected_value = reward + (1.0 - done) * gamma * target_value
    expected_value = torch.clamp(expected_value, min_value, max_value)

    value = value_net(state, action)
    value_loss = value_criterion(value, expected_value.detach())

    policy_optimizer.zero_grad()
    policy_feature_optimizer.zero_grad()

    ############################################################
    policy_loss.backward(retain_graph=True)
    hotplug.update(hp.actor_feature_lr)
    state_val = torch.FloatTensor(state_val).to(device)
    state_feature_val = policy_feature_net(state_val)
    policy_loss_val = value_net(state_val, policy_net(state_feature_val))
    policy_loss_val = -policy_loss_val.mean()
    policy_loss_val = policy_loss_val

    ############################################################
    loss_auxiliary.backward(create_graph=True)
    hotplug.update(hp.actor_feature_lr)
    state_feature_val_new = policy_feature_net(state_val)
    policy_loss_val_new = value_net(state_val, policy_net(state_feature_val_new))
    policy_loss_val_new = -policy_loss_val_new.mean()

    policy_loss_val_new = policy_loss_val_new

    utility = policy_loss_val - policy_loss_val_new
    utility = torch.tanh(utility)
    loss_meta = -utility

    omega_optim.zero_grad()
    grad_omega = torch.autograd.grad(loss_meta, critic.parameters())
    #print(grad_omega)
    for gradient, variable in zip(grad_omega, critic.parameters()):
        variable.grad.data = gradient
    omega_optim.step()

    policy_optimizer.step()
    policy_feature_optimizer.step()
    #print('loss aux is %f, loss meta is %f.'%(loss_auxiliary, utility))

    hotplug.restore()

    value_optimizer.zero_grad()
    value_loss.backward()
    value_optimizer.step()

    for target_param, param in zip(target_value_net.parameters(), value_net.parameters()):
        target_param.data.copy_(
            target_param.data * (1.0 - soft_tau) + param.data * soft_tau
        )

    for target_param, param in zip(target_policy_net.parameters(), policy_net.parameters()):
        target_param.data.copy_(
            target_param.data * (1.0 - soft_tau) + param.data * soft_tau
        )

    for target_param, param in zip(target_policy_feature_net.parameters(), policy_feature_net.parameters()):
        target_param.data.copy_(
            target_param.data * (1.0 - soft_tau) + param.data * soft_tau
        )



from mujoco_envs.half_cheetah import HalfCheetahEnv
from mujoco_envs.hopper import HopperEnv
from mujoco_envs.inverted_pendulum import InvertedPendulumEnv
from mujoco_envs.inverted_double_pendulum import InvertedDoublePendulumEnv
from mujoco_envs.walker2d import Walker2dEnv

env_name = "half_cheetah_gym"

if env_name == "half_cheetah":
    env = NormalizedActions(HalfCheetahEnv())
elif env_name == "half_cheetah_gym":
    env = NormalizedActions(gym.make('HalfCheetah-v2'))
elif env_name == "hopper":
    env = NormalizedActions(HopperEnv())
elif env_name == "inverted_pendulum":
    env = NormalizedActions(InvertedPendulumEnv())
elif env_name == "inverted_double_pendulum":
    env = NormalizedActions(InvertedDoublePendulumEnv())
elif env_name == "walker2d":
    env = NormalizedActions(Walker2dEnv())

time_dir = str(int(time.time()))
if not os.path.exists('logs/%s/ddpg_aux/%s/'%(env_name,time_dir)):
    os.makedirs('logs/%s/ddpg_aux/%s/'%(env_name,time_dir))
if not os.path.exists('model_output/%s/ddpg_aux/%s/'%(env_name,time_dir)):
    os.makedirs('model_output/%s/ddpg_aux/%s/'%(env_name,time_dir))

flags_log = os.path.join('logs/%s/ddpg_aux/%s/'%(env_name,time_dir), 'ddpg_aux_training_log.txt')
model_path = 'model_output/%s/ddpg_aux/%s/'%(env_name,time_dir)
plot_path = 'logs/%s/ddpg_aux/%s/ddpg_aux.jpg' % (env_name,time_dir)

hp_log = {}

hp_log['critic_lr'] = hp.critic_lr
hp_log['actor_lr'] = hp.actor_lr
hp_log['actor_feature_lr'] = hp.actor_feature_lr
hp_log['aux_lr'] = hp.aux_lr
hp_log['weight_decay'] = hp.weight_decay
hp_log['batch_size'] = hp.batch_size
hp_log['env_name'] = env_name
hp_log['time_dir'] = time_dir
hp_log['method'] = "ddpg_aux"

write_log(hp_log, flags_log)
print(hp_log)


#env = NormalizedActions(gym.make("Pendulum-v0"))
#env = makeFilteredEnv(gym.make("Hopper-v2"))
#env = NormalizedActions(gym.make("Hopper-v2"))
ou_noise = OUNoise(env.action_space)

state_dim = env.observation_space.shape[0]
action_dim = env.action_space.shape[0]
hidden_dim = 256

value_net = ValueNetwork(state_dim, action_dim, hidden_dim).to(device)
policy_net = PolicyNetwork_D(action_dim, hidden_dim).to(device)
policy_feature_net = PolicyFeature(state_dim, hidden_dim).to(device)


target_value_net = ValueNetwork(state_dim, action_dim, hidden_dim).to(device)
target_policy_net = PolicyNetwork_D(action_dim, hidden_dim).to(device)
target_policy_feature_net = PolicyFeature(state_dim, hidden_dim).to(device)


for target_param, param in zip(target_value_net.parameters(), value_net.parameters()):
    target_param.data.copy_(param.data)

for target_param, param in zip(target_policy_net.parameters(), policy_net.parameters()):
    target_param.data.copy_(param.data)

for target_param, param in zip(target_policy_feature_net.parameters(), policy_feature_net.parameters()):
    target_param.data.copy_(param.data)

value_lr = hp.critic_lr
policy_lr = hp.actor_lr

critic = Critic_Network(hidden_dim).cuda()
omega_optim = torch.optim.Adam(critic.parameters(), lr=hp.aux_lr, weight_decay = hp.weight_decay)
#omega_optim = torch.optim.Adam(critic.parameters(), lr=hp.aux_lr)

value_optimizer = optim.Adam(value_net.parameters(), lr=value_lr)
policy_optimizer = optim.Adam(policy_net.parameters(), lr=policy_lr)
policy_feature_optimizer = optim.Adam(policy_feature_net.parameters(), lr=hp.actor_feature_lr)

feature_net = nn.Sequential(*list(policy_feature_net.children())[:-1])
hotplug = Hot_Plug(feature_net)

value_criterion = nn.MSELoss()

replay_buffer_size = 1000000
replay_buffer = ReplayBuffer(replay_buffer_size)

max_frames  = 10000
max_steps   = 500
frame_idx   = 0
rewards     = []
batch_size  = hp.batch_size

max_reward = 0.0
TEST = 10
state = env.reset()
while frame_idx < max_frames:
    state = env.reset()
    ou_noise.reset()
    for step in range(1000):
        state_var = torch.FloatTensor(state).unsqueeze(0).to(device)
        state_feature = policy_feature_net(state_var)
        action = policy_net.get_action(state_feature)
        action = ou_noise.get_action(action, step)
        next_state, reward, done, _ = env.step(action)

        replay_buffer.push(state, action, reward, next_state, done)
        if len(replay_buffer) > batch_size:
            ddpg_update(batch_size)
        state = next_state
        if done :
            break

    if frame_idx > 100:
        episode_reward = 0
        for i in range(TEST):
            state = env.reset()
            for step in range(1000):
                state_var = torch.FloatTensor(state).unsqueeze(0).to(device)
                state_feature = policy_feature_net(state_var)
                action = policy_net.get_action(state_feature)
                next_state, reward, done, _ = env.step(action)
                state = next_state
                episode_reward += reward
                if done:
                    break
        episode_reward = episode_reward / TEST
        if episode_reward > max_reward:
            print('greedy reward')
            max_reward = episode_reward
            outfile = os.path.join(model_path, 'best_model.tar')
            torch.save((policy_net.state_dict(),policy_feature_net.state_dict(), value_net.state_dict(), critic.state_dict()), outfile)
        print('frame_idx is %d, step is %d, reward is %f.' % (frame_idx, step, episode_reward))
        reward_str = "frame id is %d, test result: %f" % (frame_idx, episode_reward)
        write_log(reward_str, flags_log)

        rewards.append(episode_reward)
        plot(frame_idx, rewards,plot_path)

    frame_idx += 1


np.save('logs/%s/ddpg_aux/%s/ddpg_aux'%(env_name,time_dir), rewards)
