import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import csv

def sliding_mean(data_array, window=5):
    data_array = np.array(data_array)
    new_list = []
    for i in range(len(data_array)):
        indices = list(range(max(i - window + 1, 0),
                             min(i + window + 1, len(data_array))))
        avg = 0
        for j in indices:
            avg += data_array[j]
        avg /= float(len(indices))
        new_list.append(avg)

    return np.array(new_list)

smooth_curve = True
def get_data(model_path):
    with open(model_path) as f:
        reader = csv.reader(f)
        header_row = next(reader)
        print(header_row)
        average_reward_train, average_reward_test = [], []
        for row in reader:
            average_reward_train.append(float(row[29]))
            average_reward_test.append(float(row[30]))

    if smooth_curve:
        clean_statistics_train = sliding_mean(average_reward_train, window=10)
        clean_statistics_test = sliding_mean(average_reward_test, window=10)
    else:
        clean_statistics_train = average_reward_train
        clean_statistics_test = average_reward_test

    return clean_statistics_train,  clean_statistics_test

model_path = []
env_name = 'half-cheetah-vel'
method = 'pearl_1561886974'
model_path.append('output/%s/%s/progress.csv'%(env_name, method))
plot_path = 'output/%s/%s/results.jpg'%(env_name, method)
results_all = []
for file in model_path:
    results_all.append(get_data(file))

for rel in results_all[0]:
    if smooth_curve:
        results_tmp = rel.tolist()
    else:
        results_tmp = rel
    frame_id = results_tmp.index(max(results_tmp))
    print(frame_id)
    print(max(results_tmp))
    print('******************************')


plt.title('Learning curve in %s'%(env_name))
plt.xlabel('Episode'), plt.ylabel('Average Reward'), plt.legend(loc='best')


plt.plot(results_all[0][0], color='#FFA500', label="Train")
plt.plot(results_all[0][1], color='#FF0000', label="Test")


plt.tight_layout()
plt.legend()
# plt.show()
plt.savefig(plot_path)
plt.close('all')