# -*- coding: utf-8 -*-
# @Time    : 2019/4/4 10:39
# @Author  : RIO
# @desc: n个人围成一圈，报数，m的人离开。直至最后只有一个人

