# -*- coding: utf-8 -*-
# @Time    : 2019/2/22 10:40
# @Author  : RIO
# @desc: TODO:DESC
import os

if not os.path.exists('/data/apdsfa/adfa/'):
    os.makedirs('/data/adf/adfa/adfa/asdf')